import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;


public class Pinball extends JPanel {
    JMenuBar menuBar = new JMenuBar();
    JMenu fileMenu = new JMenu( "文件" );
    JMenu editMenu = new JMenu( "编辑" );

    JMenuItem no = new JMenuItem( "没有" );

    //菜单项组件
    JMenuItem copy = new JMenuItem( "复制" );
    JMenuItem paste = new JMenuItem( "粘贴" );


    JToolBar toolBar= new JToolBar("颜色");
    JButton red = new JButton("红色");
    JButton green = new JButton("绿色");
    JButton yellow = new JButton("黄色");


    private JLabel scoreLabel;//分数
    private int score;//分数

    private JLabel timeLabel;
    private int time;//时间
    private int ballX = 100;//发球的位置
    private int ballY = 100;//发球的位置
    private int ballRadius = 20;//球的半径
    private int ballDeltaX = 2;//球的速度
    private int ballDeltaY = 2;//球的速度

    private int paddleX = 200;//挡板的起始位置
    private int paddleY = 500;//挡板的起始位置
    private int paddleWidth = 100;//挡板的宽度
    private int paddleHeight = 20;//挡板的高度
    private int paddleDelta = 5;//挡板的速度

    private Timer timer;//刷新率的定时器
    private Timer timer2;//计时器的定时器
    private boolean leftPressed = false;//左键
    private boolean rightPressed = false;//右键

    public Pinball() {

        toolBar.add(red);
        toolBar.add(green);
        toolBar.add(yellow);

//单击顔色按钮时，焦点将移动到顔色按钮，并一直保留在那里
        red.addActionListener(e -> {
            setBackground(Color.RED);
            this.requestFocusInWindow(); // 請求焦點回到面板
        });
        green.addActionListener(e -> {
            setBackground(Color.GREEN);
            this.requestFocusInWindow(); // 請求焦點回到面板
        });
        yellow.addActionListener(e -> {
            setBackground(Color.YELLOW);
            this.requestFocusInWindow(); // 請求焦點回到面板
        });

        add(toolBar);//添加工具栏


        score = 0;//分数
        scoreLabel = new JLabel("得分: " + score);
        scoreLabel.setForeground(Color.RED);//分数颜色
        scoreLabel.setFont(new Font("楷体", Font.PLAIN, 20));//分数字体
        add(scoreLabel);


        time = 0;//时间计数器
        timeLabel = new JLabel("时间: " + formatTime(time));//时间标签
        add(timeLabel);
        timer2 = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                time++;
                timeLabel.setText("时间: " + formatTime(time));
            }
        });
        timer2.start();

        setPreferredSize(new Dimension(800, 600));//设置窗口大小
        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {//键盘监听
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {//左键
                    leftPressed = true;//按下
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {//右键
                    rightPressed = true;//按下
                }
            }

            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {//左键
                    leftPressed = false;//松开
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {//右键
                    rightPressed = false;//松开
                }
            }
        });
        timer = new Timer(1, new ActionListener() {//刷新率
            public void actionPerformed(ActionEvent e) {//每次刷新
                update();//更新
                repaint();//刷新率
            }
        });
        timer.start();
    }

    public void setMenuBarToFrame(JFrame frame) {
        frame.setJMenuBar(menuBar);
        //设置frame最佳大学=小可见
        frame.pack();
        frame.setVisible(true);

        fileMenu.add( no );//把菜单项放入菜单中
        editMenu.add( copy );
        editMenu.add( paste );

        //组装菜单条
        menuBar.add( fileMenu );
        menuBar.add( editMenu );

        //把菜单放入frame中
        frame.setJMenuBar( menuBar );

        //设置frame最佳大学=小可见
        frame.pack();
        frame.setVisible( true );
    }

    private String formatTime(int time) {

        int minutes = time / 60;//分钟
        int seconds = time % 60;//秒
        return String.format("%02d:%02d", minutes, seconds);
    }

    private void update() {

        if (ballY + ballRadius >= paddleY && ballY - ballRadius <= paddleY + paddleHeight) {
            if (ballX + ballRadius >= paddleX && ballX - ballRadius <= paddleX + paddleWidth) {
                ballDeltaY *= -1;
                score++; // increase score
                scoreLabel.setText("得分: " + score); // 更新分数展示
            }
        }

        ballX += ballDeltaX;//球的位置
        ballY += ballDeltaY;

        // 防止球脱离屏幕
        if (ballX + ballRadius > getWidth() || ballX - ballRadius < 0) {
            ballDeltaX *= -1;
        }//碰到左右边界
        if (ballY - ballRadius < 0) {
            ballDeltaY *= -1;
        }

        // 从挡板上反弹
        if (ballY + ballRadius >= paddleY && ballY - ballRadius <= paddleY + paddleHeight) {
            if (ballX + ballRadius >= paddleX && ballX - ballRadius <= paddleX + paddleWidth) {
                ballDeltaY *= -1;
            }//碰到挡板
        }
        if (leftPressed && paddleX > 0) {
            paddleX -= paddleDelta;
        }//左键
        if (rightPressed && paddleX + paddleWidth < getWidth()) {
            paddleX += paddleDelta;
        }//右键

        //游戏结束
        if (ballY + ballRadius > getHeight()) {
            timer.stop();
            timer2.stop();

        }

        if (ballY + ballRadius > getHeight()) {//球的位置大于挡板是游戏结束
            timer.stop();
            timer2.stop();

            JButton endGameButton = new JButton("結束");
            Object[] options = { endGameButton};
            JLabel message = new JLabel("游戲結束，游戲時長: " + formatTime(time));
            message.setHorizontalAlignment(JLabel.CENTER);
            JOptionPane pane = new JOptionPane(message, JOptionPane.PLAIN_MESSAGE,
                    JOptionPane.DEFAULT_OPTION, null, options, null);
            JDialog dialog = pane.createDialog(this, "游戲結束");
            dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);

            endGameButton.addActionListener(e -> {//结束游戏
                System.exit(0);
            });
            dialog.setVisible(true);

        }




//键盘控制挡板的移动,使球反弹
        ballX += ballDeltaX;
        ballY += ballDeltaY;

        if (leftPressed && paddleX > 0) {
            paddleX -= paddleDelta;
        }
        if (rightPressed && paddleX + paddleWidth < getWidth()) {
            paddleX += paddleDelta;
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);//用于清除之前的绘制内容
        g.setColor(Color.BLACK);
        g.fillOval(ballX - ballRadius, ballY - ballRadius, 2 * ballRadius, 2 * ballRadius);//画球
        g.fillRect(paddleX, paddleY, paddleWidth, paddleHeight);//画板
    }





    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame frame = new JFrame("彈球游戲");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

                Pinball pinball = new Pinball();
                pinball.setMenuBarToFrame(frame);

                frame.setContentPane(pinball);
                frame.pack();
                frame.setVisible(true);
            }
        });
    }
}





