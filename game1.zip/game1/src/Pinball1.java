import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


//原稿，未修改，用于还原。

public class Pinball1 extends JPanel {
    private JLabel timeLabel;
    private int time;
    private int ballX = 100;
    private int ballY = 100;
    private int ballRadius = 20;
    private int ballDeltaX = 3;
    private int ballDeltaY = 3;
    private int vPaddleX;
    private int vPaddleY;

    private final int vPaddleWidth = 20;
    private final int vPaddleHeight = 100;
    private int paddleX = 200;
    private int paddleY = 500;
    private int paddleWidth = 80;
    private int paddleHeight = 20;
    private int paddleDelta = 10;
    private Timer timer;
    private boolean leftPressed = false;
    private boolean rightPressed = false;

    public Pinball1() {

        time = 0;
        timeLabel = new JLabel("时间: " + formatTime(time));
        add(timeLabel);


        Timer timer2 = new Timer(1000, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                time++;
                timeLabel.setText("时间: " + formatTime(time));
            }
        });
        timer2.start();

        vPaddleX = 200;
        vPaddleY = 200;

        setPreferredSize(new Dimension(800, 600));
        setFocusable(true);
        addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    leftPressed = true;
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    rightPressed = true;
                }
            }

            public void keyReleased(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                    leftPressed = false;
                } else if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                    rightPressed = false;
                }
            }
        });
        timer = new Timer(15, new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                update();
                repaint();
            }
        });
        timer.start();
    }

    private String formatTime(int time) {
        int hours = time / 3600;
        int minutes = (time % 3600) / 60;
        int seconds = time % 60;
        return String.format("%02d:%02d:%02d", hours, minutes, seconds);
    }


    private void update() {

        if (ballY + ballRadius >= vPaddleY && ballY - ballRadius <= vPaddleY + vPaddleHeight && ballX + ballRadius > vPaddleX && ballX - ballRadius < vPaddleX + vPaddleWidth) {
            ballDeltaX *= -1; // 反射沿水平轴
        }


        if (ballY + ballRadius > getHeight()) {
            timer.stop();
            JButton tryAgainButton = new JButton("Try Again");
            JButton endGameButton = new JButton("End Game");
            Object[] options = {tryAgainButton, endGameButton};

            JOptionPane pane = new JOptionPane("Game Over", JOptionPane.PLAIN_MESSAGE, JOptionPane.DEFAULT_OPTION, null, options, null);
            tryAgainButton.addActionListener(e -> {
                timer.restart();
                ballX = 100;
                ballY = 100;
                paddleX = 200;
                paddleY = 500;
            });
            endGameButton.addActionListener(e -> {
                System.exit(0);
            });
            JDialog dialog = pane.createDialog(this, "Game Over");
            dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
            dialog.setVisible(true);
        }
        ballX += ballDeltaX;
        ballY += ballDeltaY;
        if (leftPressed) {
            paddleX -= paddleDelta;
        }
        if (rightPressed) {
            paddleX += paddleDelta;
        }
        if (ballX - ballRadius < 0 || ballX + ballRadius > getWidth()) {
            ballDeltaX *= -1; // Reflect along vertical axis
        }
        if (ballY - ballRadius < 0) {
            ballDeltaY *= -1; // Reflect along horizontal axis
        }
        if (ballY + ballRadius >= paddleY && ballY + ballRadius <= paddleY + paddleHeight && ballX + ballRadius > paddleX && ballX - ballRadius < paddleX + paddleWidth) {
            ballDeltaY *= -1; // Reflect along horizontal axis
        }
        if (paddleX < 0) {
            paddleX = 0;
        } else if (paddleX + paddleWidth > getWidth()) {
            paddleX = getWidth() - paddleWidth;
        }
        if (ballY + ballRadius > getHeight()) {
            timer.stop();
            JButton tryAgainButton = new JButton("再來一次");
            JButton endGameButton = new JButton("結束");
            Object[] options = {tryAgainButton, endGameButton};
            JLabel message = new JLabel("游戲結束");
            message.setHorizontalAlignment(JLabel.CENTER);
            JOptionPane pane = new JOptionPane(message, JOptionPane.PLAIN_MESSAGE, JOptionPane.DEFAULT_OPTION, null, options, null);
            JDialog dialog = pane.createDialog(this, "Game Over");
            dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);
            tryAgainButton.addActionListener(e -> {
                timer.restart();
                ballX = 100;
                ballY = 100;
                paddleX = 200;
                paddleY = 500;
                dialog.dispose(); // close the dialog
            });
            endGameButton.addActionListener(e -> {
                System.exit(0);
            });
            dialog.setVisible(true);
        }
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.setColor(Color.BLACK);
        g.fillOval(ballX - ballRadius, ballY - ballRadius, 2 * ballRadius, 2 * ballRadius);
        g.fillRect(paddleX, paddleY, paddleWidth, paddleHeight);
        g.fillRect(vPaddleX, vPaddleY, vPaddleWidth, vPaddleHeight); // 绘制竖挡板
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                JFrame frame = new JFrame("彈球游戲");
                frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                frame.setContentPane(new Pinball1());
                frame.pack();
                frame.setVisible(true);
            }
        });
    }

}
